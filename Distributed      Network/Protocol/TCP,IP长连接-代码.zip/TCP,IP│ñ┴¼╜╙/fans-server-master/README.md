# fans_server
同时支持TCP和WebSocket长连接服务 
server端：https://github.com/name5566/leaf

聊天demo: http://smart.guoxingjun.com    

效果如图：

![alt text](http://smart.guoxingjun.com/image/chat.png "chat")

微信小程序聊天推送消息：(微信默认支持websocket)

![alt text](http://smart.guoxingjun.com/image/wx.png "wx")

![alt text](http://smart.guoxingjun.com/image/wx2.png "wx")
