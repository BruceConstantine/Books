package com.megagao.production.ssm.domain.vo;


import com.megagao.production.ssm.domain.TechnologyPlan;

public class TechnologyPlanVO extends TechnologyPlan{
	
	private String technologyName;

	public String getTechnologyName() {
		return technologyName;
	}

	public void setTechnologyName(String technologyName) {
		this.technologyName = technologyName;
	}
	
}