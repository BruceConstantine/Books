package com.megagao.production.ssm.common;

/**
 * Created by megagao on 2017/12/22.
 */
public class Constants {
    public static final String ACTIVE_USER = "activeUser";
    public static final String VALIDATE_CODE = "validateCode";

    public static final String NO_PERMISSION = "no permission : ";

    public static final String ERROR_HAPPENS = "error happens : ";
}
